
let audio = document.getElementById('audioPlayer');
function playAudio() { audio.play(); }
function pauseAudio() { audio.pause(); }
